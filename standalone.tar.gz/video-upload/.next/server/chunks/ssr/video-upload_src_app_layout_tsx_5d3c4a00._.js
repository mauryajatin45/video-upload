module.exports=[17806,a=>{"use strict";var b=a.i(65111);function c({children:a}){return(0,b.jsx)("html",{lang:"en",children:(0,b.jsx)("body",{className:"antialiased",children:a})})}a.s(["default",()=>c,"metadata",0,{title:"Video Upload",description:"Upload your video"}])}];

//# sourceMappingURL=video-upload_src_app_layout_tsx_5d3c4a00._.js.map