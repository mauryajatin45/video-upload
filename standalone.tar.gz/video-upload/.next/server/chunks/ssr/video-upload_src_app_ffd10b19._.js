module.exports=[44532,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},60624,a=>{"use strict";let b={src:a.i(44532).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=video-upload_src_app_ffd10b19._.js.map