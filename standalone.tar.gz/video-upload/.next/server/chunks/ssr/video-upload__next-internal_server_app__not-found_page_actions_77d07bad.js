module.exports=[29457,(a,b,c)=>{}];

//# sourceMappingURL=video-upload__next-internal_server_app__not-found_page_actions_77d07bad.js.map