module.exports=[19930,(a,b,c)=>{}];

//# sourceMappingURL=video-upload__next-internal_server_app_upload_page_actions_8638871d.js.map