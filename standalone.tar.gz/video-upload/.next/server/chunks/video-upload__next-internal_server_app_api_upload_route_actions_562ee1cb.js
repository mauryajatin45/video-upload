module.exports=[52068,(e,o,d)=>{}];

//# sourceMappingURL=video-upload__next-internal_server_app_api_upload_route_actions_562ee1cb.js.map