module.exports=[66622,(e,o,d)=>{}];

//# sourceMappingURL=video-upload__next-internal_server_app_favicon_ico_route_actions_be606474.js.map