var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/upload/route.js")
R.c("server/chunks/[root-of-the-server]__93b8f2fa._.js")
R.c("server/chunks/[root-of-the-server]__8f53a8aa._.js")
R.c("server/chunks/[root-of-the-server]__5e1764f6._.js")
R.c("server/chunks/video-upload__next-internal_server_app_api_upload_route_actions_562ee1cb.js")
R.m(49802)
module.exports=R.m(49802).exports
