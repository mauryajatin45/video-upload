var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_03fe02e0._.js")
R.c("server/chunks/[root-of-the-server]__5e1764f6._.js")
R.c("server/chunks/c2428_next_dist_esm_build_templates_app-route_e468951f.js")
R.c("server/chunks/video-upload__next-internal_server_app_favicon_ico_route_actions_be606474.js")
R.m(32489)
module.exports=R.m(32489).exports
